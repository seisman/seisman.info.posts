#ifndef _NR_H_
#define _NR_H_

void eigsrt(float d[], float **v, int n);
void jacobi(float **a, int n, float d[], float **v, int *nrot);

#endif /* _NR_H_ */
