/*
 *  Convert Sun Raster Image to XBM format
 *
 *  Author: SeisMan 
 *  Date:   11/01/2013
 *
 */

#include <stdio.h>
#include <stdlib.h>
struct RASTER_HEADER {
	int magic;
	int width;
	int height;
	int depth;
	int length;
	int type;
	int maptype;
	int maplength;
};
typedef struct RASTER_HEADER RASTER;
void swab4(char *pt, int n);

int main(int argc, char *argv[]){
	FILE *fip, *fop;
	char infile[80];
	char outfile[80];

	RASTER hd;
	unsigned char *Red, *Green, *Blue;
	unsigned char **Pixel;

    int error;
    
    error = 0;
    for (int i=1; !error && i<argc; i++) {
        if (argv[i][0]=='-') {
            switch(argv[i][1]) {
                case 'I':
                    if (sscanf(&argv[i][2], "%s", infile) !=1 ) error++;
                    break;
                case 'O':
                    if (sscanf(&argv[i][2], "%s", outfile) !=1 ) error++;
                    break;
            }
        }
    }
    
    if (argc == 1 || error) {
        fprintf(stderr, "Usage: %s -Iraster -Oxbm\n", argv[0]);
        exit(-1);
    }

	if ((fip=fopen(infile, "rb"))==NULL) {
		fprintf(stderr, "Error in opening file %s", infile);	
		exit(-1);
	}

	/* Read Header Information*/
	fread(&hd, sizeof(RASTER), 1, fip);

	if (hd.magic == 0x956aa659) {
		swab4((char *)&hd,sizeof(RASTER));
	}
	
	#ifdef DEBUG
	fprintf(stderr, "Raster Header Information:");
	fprintf(stderr, "  magic  = %X\n", hd.magic);
	fprintf(stderr, "  width  = %d\n", hd.width);
	fprintf(stderr, "  height = %d\n", hd.height);
	fprintf(stderr, "  depth  = %d\n", hd.depth);
	fprintf(stderr, "  length = %d\n", hd.length);
	fprintf(stderr, "  type   = %d\n", hd.type);
	fprintf(stderr, "  maptype = %d\n", hd.maptype);
	fprintf(stderr, "  maplength = %d\n", hd.maplength);
	#endif

	if (hd.type != 1) {
		fprintf(stderr, "Encoding Type != 1\n");
		exit(-1);
	} 
	if (hd.maptype != 1) {
		fprintf(stderr, "MapType != 1\n");
		exit(-1);
	}

	int len = hd.maplength/3;
	Red = (unsigned char *)malloc(sizeof(char)*len);
	Green = (unsigned char *)malloc(sizeof(char)*len);
	Blue = (unsigned char *)malloc(sizeof(char)*len);

	fread(Red, sizeof(char), len, fip);
	fread(Green, sizeof(char), len, fip);
	fread(Blue, sizeof(char), len, fip);

	#ifdef DEBUG
	fprintf(stderr, "Color Table Infomation\n");
	fprintf(stderr, "  No.\tRed\tGreen\tBlue\n");
	for (int i=0; i<len; i++){
		fprintf(stderr, "  %03d\t%0d\t%0d\t%0d\n", i, Red[i], Green[i], Blue[i]);
	}
	#endif

	Pixel = (unsigned char **)malloc(hd.height*sizeof(unsigned char *));
	for (int i=0; i< hd.height; i++) {
		Pixel[i] = (unsigned char *)malloc(hd.width*sizeof(unsigned char));
		fread(Pixel[i], sizeof(unsigned char), hd.width, fip);
	}

	if ((fop=fopen(outfile, "w"))==NULL) {
		fprintf(stderr, "Error in opening file %s", outfile);	
		exit(-1);
	}
	
	int count=0;
	for (int i=0; i<hd.height; i++){
		for (int j=0; j<hd.width; j++){
			count++;
			fprintf(fop, "0x%02X,  ", Pixel[i][j]);
			if (count%12==0) fprintf(fop, "\n");
		}
	}

	return 0;
}

void swab4(char *pt, int n){
	int i;
	char temp;
	for(i=0;i<n;i+=4) {
		temp = pt[i+3];
		pt[i+3] = pt[i];
		pt[i] = temp;
		temp = pt[i+2];
		pt[i+2] = pt[i+1];
		pt[i+1] = temp;
	}
}
